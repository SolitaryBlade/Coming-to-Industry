{
"opposites":["虚无"]
}
