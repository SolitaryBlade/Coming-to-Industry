Events.on(EventType.ClientLoadEvent, cons(e => {
	var dialog = new JavaAdapter(BaseDialog, {}, "V154+ 将至[CTI]	当前版本号[Now Vision]:v5.4-----2026 2/22 18:35");
	var icon = new Packages.arc.scene.style.TextureRegionDrawable(Core.atlas.find("将至-提示", Core.atlas.find("clear")));
	dialog.shown(run(() => {
		dialog.cont.table(Tex.button, cons(t => {
			t.defaults().size(400, 200).left();
			t.button("我已知晓\n确认关闭\nI already know.\nConfirm Close", icon, Styles.cleart, run(() => {
				dialog.hide();
			}));
			t.add("如有任何问题\n欢迎前往Q群602687492进行反馈\n如果是BETA版本，\n崩溃卡死等问题可能比较常见\n[red]注意:本模组已应用原版单位强化\n原版单位生命值已提升2-3倍\n单位伤害提高两倍或持有更多武器\n且部分单位持有特殊能力\nSorry the English version does \nnot currently support bug feedback")
		}));
	}));
	dialog.show();
}));